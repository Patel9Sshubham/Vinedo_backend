# Vinedo_backend
backend code in Nodejs

# production base url
https://vinedo.myappsdevelopment.co.in/

# postman collection url 
https://e-commerce-2625.postman.co/workspace/vinedo~388fd47f-bcbd-47b1-8d5d-bbb95177da03/collection/40834155-6b0c590a-f476-4fe8-95f6-4f91c1905868?action=share&creator=40834155